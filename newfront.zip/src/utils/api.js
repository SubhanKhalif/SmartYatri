const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Helper function to get auth token
const getToken = () => {
  return localStorage.getItem('token') || document.cookie
    .split('; ')
    .find(row => row.startsWith('token='))
    ?.split('=')[1];
};

// Main API request function
const apiRequest = async (endpoint, options = {}) => {
  const token = getToken();
  
  const config = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
    credentials: 'include', // Include cookies
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Request failed');
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

// Auth API
export const authAPI = {
  register: (data) => apiRequest('/auth/register', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  
  login: (data) => apiRequest('/auth/login', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  
  logout: () => apiRequest('/auth/logout', {
    method: 'POST',
  }),
  
  getCurrentUser: () => apiRequest('/auth/me'),
  
  getQRCode: () => apiRequest('/auth/qr-code'),
};

// Pass API
export const passAPI = {
  getMyPasses: () => apiRequest('/passes/my-passes'),
  getCurrentPass: () => apiRequest('/passes/current'),
  purchasePass: (data) => apiRequest('/passes/purchase', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  getPassHistory: () => apiRequest('/passes/history'),
};

// Manager API
export const managerAPI = {
  getDashboardStats: () => apiRequest('/manager/dashboard/stats'),
  getPendingPasses: () => apiRequest('/manager/passes/pending'),
  approvePass: (passId) => apiRequest(`/manager/passes/${passId}/approve`, {
    method: 'POST',
  }),
  rejectPass: (passId, reason) => apiRequest(`/manager/passes/${passId}/reject`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  }),
  createBus: (data) => apiRequest('/manager/buses', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  getBuses: () => apiRequest('/manager/buses'),
  updateBus: (busId, data) => apiRequest(`/manager/buses/${busId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  createRoute: (data) => apiRequest('/manager/routes', {
    method: 'POST',
    body: JSON.stringify(data),
  }),
  getRoutes: () => apiRequest('/manager/routes'),
  updateRoute: (routeId, data) => apiRequest(`/manager/routes/${routeId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  }),
  getScanActivity: (limit) => apiRequest(`/manager/scans?limit=${limit || 50}`),
};

// Conductor API
export const conductorAPI = {
  scanQR: (qrId) => apiRequest('/conductor/scan', {
    method: 'POST',
    body: JSON.stringify({ qrId }),
  }),
  getScanHistory: (limit) => apiRequest(`/conductor/scans?limit=${limit || 50}`),
};

// Route API
export const routeAPI = {
  getActiveRoutes: () => apiRequest('/routes/active'),
};

// Notification API
export const notificationAPI = {
  getNotifications: (unreadOnly) => apiRequest(`/notifications?unreadOnly=${unreadOnly || false}`),
  markAsRead: (notificationId) => apiRequest(`/notifications/${notificationId}/read`, {
    method: 'PUT',
  }),
  markAllAsRead: () => apiRequest('/notifications/read-all', {
    method: 'PUT',
  }),
};

