import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../styles/global.css';

const Layout = ({ children, title }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const getRoleRoutes = () => {
    if (!user) return [];
    
    const role = user.role;
    if (role === 'STUDENT' || role === 'STAFF') {
      return [
        { path: '/student/dashboard', label: 'Dashboard', icon: '📊' },
        { path: '/student/book-ticket', label: 'Buy Pass', icon: '🎫' },
        { path: '/student/my-pass', label: 'My Pass', icon: '🎟️' },
        { path: '/student/travel-history', label: 'History', icon: '📜' },
      ];
    } else if (role === 'MANAGER') {
      return [
        { path: '/manager/dashboard', label: 'Dashboard', icon: '📊' },
        { path: '/manager/approve-passes', label: 'Approve Passes', icon: '✅' },
        { path: '/manager/routes', label: 'Routes', icon: '🛣️' },
        { path: '/manager/buses', label: 'Buses', icon: '🚌' },
        { path: '/manager/users', label: 'Users', icon: '👥' },
      ];
    } else if (role === 'CONDUCTOR') {
      return [
        { path: '/conductor/scanner', label: 'Scanner', icon: '📱' },
      ];
    }
    return [];
  };

  const routes = getRoleRoutes();

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-secondary)' }}>
      {/* Top Navigation */}
      <header style={{ background: 'white', borderBottom: '1px solid var(--border)', padding: '1rem 0' }}>
        <div className="container">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <Link to="/" style={{ textDecoration: 'none', color: 'var(--text-primary)' }}>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>🚌 Bus Pass</h2>
              </Link>
              <nav className="flex gap-4" style={{ display: 'none' }}>
                {routes.map((route) => (
                  <Link
                    key={route.path}
                    to={route.path}
                    style={{ textDecoration: 'none', color: 'var(--text-secondary)', fontSize: '0.875rem' }}
                  >
                    {route.label}
                  </Link>
                ))}
              </nav>
            </div>
            <div className="flex items-center gap-4">
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>
                {user?.name || user?.email}
              </span>
              <span className="badge badge-info" style={{ textTransform: 'capitalize' }}>
                {user?.role?.toLowerCase()}
              </span>
              <button onClick={handleLogout} className="btn btn-sm btn-outline">
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container" style={{ padding: '2rem 0' }}>
        {title && (
          <h1 style={{ marginBottom: '2rem', fontSize: '2rem' }}>{title}</h1>
        )}
        {children}
      </div>
    </div>
  );
};

export default Layout;

