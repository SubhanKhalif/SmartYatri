import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { managerAPI } from '../../utils/api';
import '../../styles/global.css';

const ManageRoutes = () => {
  const [routes, setRoutes] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    startPoint: '',
    endPoint: '',
    stops: '',
    scheduleTime: '',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadRoutes();
  }, []);

  const loadRoutes = async () => {
    try {
      const data = await managerAPI.getRoutes();
      setRoutes(data.routes || []);
    } catch (error) {
      console.error('Failed to load routes:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const stops = formData.stops.split(',').map(s => s.trim()).filter(s => s);
      const scheduleTime = formData.scheduleTime.split(',').map(s => s.trim()).filter(s => s);
      
      await managerAPI.createRoute({
        name: formData.name,
        startPoint: formData.startPoint,
        endPoint: formData.endPoint,
        stops,
        scheduleTime,
      });
      
      alert('Route created successfully!');
      setShowForm(false);
      setFormData({ name: '', startPoint: '', endPoint: '', stops: '', scheduleTime: '' });
      loadRoutes();
    } catch (error) {
      alert('Failed to create route: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout title="Manage Routes">
      <div className="flex justify-between items-center mb-4">
        <h2>Routes</h2>
        <button onClick={() => setShowForm(!showForm)} className="btn btn-primary">
          {showForm ? 'Cancel' : '+ Add Route'}
        </button>
      </div>

      {showForm && (
        <div className="card mb-6">
          <div className="card-header">
            <h2 className="card-title">Create New Route</h2>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Route Name</label>
              <input
                type="text"
                className="form-input"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                placeholder="e.g., Route A"
              />
            </div>
            <div className="grid grid-cols-2">
              <div className="form-group">
                <label className="form-label">Start Point</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.startPoint}
                  onChange={(e) => setFormData({ ...formData, startPoint: e.target.value })}
                  required
                  placeholder="e.g., School"
                />
              </div>
              <div className="form-group">
                <label className="form-label">End Point</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.endPoint}
                  onChange={(e) => setFormData({ ...formData, endPoint: e.target.value })}
                  required
                  placeholder="e.g., City Center"
                />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Stops (comma-separated)</label>
              <input
                type="text"
                className="form-input"
                value={formData.stops}
                onChange={(e) => setFormData({ ...formData, stops: e.target.value })}
                placeholder="e.g., Stop 1, Stop 2, Stop 3"
              />
            </div>
            <div className="form-group">
              <label className="form-label">Schedule Times (comma-separated)</label>
              <input
                type="text"
                className="form-input"
                value={formData.scheduleTime}
                onChange={(e) => setFormData({ ...formData, scheduleTime: e.target.value })}
                placeholder="e.g., 08:00, 14:00, 17:00"
              />
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <span className="loading"></span> : 'Create Route'}
            </button>
          </form>
        </div>
      )}

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Start Point</th>
              <th>End Point</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {routes.map((route) => (
              <tr key={route.id}>
                <td>{route.name}</td>
                <td>{route.startPoint}</td>
                <td>{route.endPoint}</td>
                <td>
                  <span className={`badge ${route.active ? 'badge-success' : 'badge-secondary'}`}>
                    {route.active ? 'Active' : 'Inactive'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
};

export default ManageRoutes;
