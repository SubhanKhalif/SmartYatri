import Layout from '../../components/Layout';
import '../../styles/global.css';

const Reports = () => {
  return (
    <Layout title="Reports">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Reports & Analytics</h2>
        </div>
        <div className="text-center" style={{ padding: '2rem' }}>
          <p style={{ color: 'var(--text-secondary)' }}>
            Reports and analytics will be available here.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Reports;

