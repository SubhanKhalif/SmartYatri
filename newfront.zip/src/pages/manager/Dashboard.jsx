import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../../components/Layout';
import { managerAPI } from '../../utils/api';
import '../../styles/global.css';

const ManagerDashboard = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const data = await managerAPI.getDashboardStats();
      setStats(data.stats);
    } catch (error) {
      console.error('Failed to load stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout title="Manager Dashboard">
        <div className="text-center">
          <div className="loading" style={{ width: '2rem', height: '2rem', margin: '2rem auto' }}></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Manager Dashboard">
      {/* Stats Cards */}
      <div className="grid grid-cols-4 mb-6">
        <div className="card text-center">
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>👥</div>
          <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--primary)' }}>
            {stats?.totalStudents || 0}
          </div>
          <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Students</div>
        </div>
        <div className="card text-center">
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>👔</div>
          <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--primary)' }}>
            {stats?.totalStaff || 0}
          </div>
          <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Staff</div>
        </div>
        <div className="card text-center">
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>✅</div>
          <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--success)' }}>
            {stats?.activePasses || 0}
          </div>
          <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Active Passes</div>
        </div>
        <div className="card text-center">
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>⏳</div>
          <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--warning)' }}>
            {stats?.pendingApprovals || 0}
          </div>
          <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>Pending</div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-4 mb-6">
        <Link to="/manager/approve-passes" className="card text-center" style={{ textDecoration: 'none' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>✅</div>
          <h3 style={{ fontSize: '1rem' }}>Approve Passes</h3>
        </Link>
        <Link to="/manager/routes" className="card text-center" style={{ textDecoration: 'none' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🛣️</div>
          <h3 style={{ fontSize: '1rem' }}>Manage Routes</h3>
        </Link>
        <Link to="/manager/buses" className="card text-center" style={{ textDecoration: 'none' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🚌</div>
          <h3 style={{ fontSize: '1rem' }}>Manage Buses</h3>
        </Link>
        <Link to="/manager/users" className="card text-center" style={{ textDecoration: 'none' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>👥</div>
          <h3 style={{ fontSize: '1rem' }}>Manage Users</h3>
        </Link>
      </div>

      {/* Additional Stats */}
      <div className="grid grid-cols-2">
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Today's Activity</h2>
          </div>
          <div>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--primary)' }}>
              {stats?.scansToday || 0}
            </div>
            <div style={{ color: 'var(--text-secondary)' }}>Scans performed today</div>
          </div>
        </div>
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Expired Passes</h2>
          </div>
          <div>
            <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--error)' }}>
              {stats?.expiredPasses || 0}
            </div>
            <div style={{ color: 'var(--text-secondary)' }}>Total expired passes</div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ManagerDashboard;

