import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { managerAPI } from '../../utils/api';
import '../../styles/global.css';

const ApprovePasses = () => {
  const [passes, setPasses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPasses();
  }, []);

  const loadPasses = async () => {
    try {
      const data = await managerAPI.getPendingPasses();
      setPasses(data.passes || []);
    } catch (error) {
      console.error('Failed to load passes:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (passId) => {
    if (!confirm('Are you sure you want to approve this pass?')) return;
    
    try {
      await managerAPI.approvePass(passId);
      alert('Pass approved successfully!');
      loadPasses();
    } catch (error) {
      alert('Failed to approve pass: ' + error.message);
    }
  };

  const handleReject = async (passId) => {
    const reason = prompt('Please provide a reason for rejection:');
    if (!reason) return;
    
    try {
      await managerAPI.rejectPass(passId, reason);
      alert('Pass rejected successfully!');
      loadPasses();
    } catch (error) {
      alert('Failed to reject pass: ' + error.message);
    }
  };

  if (loading) {
    return (
      <Layout title="Approve Passes">
        <div className="text-center">
          <div className="loading" style={{ width: '2rem', height: '2rem', margin: '2rem auto' }}></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Approve Passes">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Pending Pass Requests</h2>
        </div>
        {passes.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>User</th>
                <th>Pass Type</th>
                <th>Route</th>
                <th>Amount</th>
                <th>Payment</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {passes.map((pass) => (
                <tr key={pass.id}>
                  <td>
                    <div>
                      <div style={{ fontWeight: '500' }}>
                        {pass.user?.profile?.fullName || pass.user?.email}
                      </div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                        {pass.user?.loginType}
                      </div>
                    </div>
                  </td>
                  <td>{pass.type}</td>
                  <td>{pass.route?.name || 'N/A'}</td>
                  <td>₹{pass.payments?.[0]?.amount || 'N/A'}</td>
                  <td>
                    {pass.payments?.[0] ? (
                      <div>
                        <div className={`badge ${pass.payments[0].status === 'PAID' ? 'badge-success' : 'badge-warning'}`}>
                          {pass.payments[0].status}
                        </div>
                        {pass.payments[0].reference && (
                          <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                            Ref: {pass.payments[0].reference}
                          </div>
                        )}
                      </div>
                    ) : (
                      <span className="badge badge-secondary">N/A</span>
                    )}
                  </td>
                  <td>{new Date(pass.createdAt).toLocaleDateString()}</td>
                  <td>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleApprove(pass.id)}
                        className="btn btn-sm btn-success"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleReject(pass.id)}
                        className="btn btn-sm btn-danger"
                      >
                        Reject
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="text-center" style={{ padding: '2rem' }}>
            <p style={{ color: 'var(--text-secondary)' }}>No pending pass requests.</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default ApprovePasses;

