import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { managerAPI } from '../../utils/api';
import '../../styles/global.css';

const ManageBuses = () => {
  const [buses, setBuses] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    busNumber: '',
    numberPlate: '',
    capacity: '',
    driverName: '',
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadBuses();
  }, []);

  const loadBuses = async () => {
    try {
      const data = await managerAPI.getBuses();
      setBuses(data.buses || []);
    } catch (error) {
      console.error('Failed to load buses:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await managerAPI.createBus(formData);
      alert('Bus created successfully!');
      setShowForm(false);
      setFormData({ busNumber: '', numberPlate: '', capacity: '', driverName: '' });
      loadBuses();
    } catch (error) {
      alert('Failed to create bus: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout title="Manage Buses">
      <div className="flex justify-between items-center mb-4">
        <h2>Buses</h2>
        <button onClick={() => setShowForm(!showForm)} className="btn btn-primary">
          {showForm ? 'Cancel' : '+ Add Bus'}
        </button>
      </div>

      {showForm && (
        <div className="card mb-6">
          <div className="card-header">
            <h2 className="card-title">Create New Bus</h2>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-2">
              <div className="form-group">
                <label className="form-label">Bus Number</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.busNumber}
                  onChange={(e) => setFormData({ ...formData, busNumber: e.target.value })}
                  required
                  placeholder="e.g., BUS-001"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Number Plate</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.numberPlate}
                  onChange={(e) => setFormData({ ...formData, numberPlate: e.target.value })}
                  required
                  placeholder="e.g., ABC-1234"
                />
              </div>
            </div>
            <div className="grid grid-cols-2">
              <div className="form-group">
                <label className="form-label">Capacity</label>
                <input
                  type="number"
                  className="form-input"
                  value={formData.capacity}
                  onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
                  required
                  min="1"
                  placeholder="e.g., 50"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Driver Name</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.driverName}
                  onChange={(e) => setFormData({ ...formData, driverName: e.target.value })}
                  placeholder="Driver name (optional)"
                />
              </div>
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <span className="loading"></span> : 'Create Bus'}
            </button>
          </form>
        </div>
      )}

      <div className="card">
        <table className="table">
          <thead>
            <tr>
              <th>Bus Number</th>
              <th>Number Plate</th>
              <th>Capacity</th>
              <th>Driver</th>
              <th>Conductor</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {buses.map((bus) => (
              <tr key={bus.id}>
                <td>{bus.busNumber}</td>
                <td>{bus.numberPlate}</td>
                <td>{bus.capacity}</td>
                <td>{bus.driverName || 'N/A'}</td>
                <td>{bus.conductor?.profile?.fullName || 'Not Assigned'}</td>
                <td>
                  <span className={`badge ${bus.active ? 'badge-success' : 'badge-secondary'}`}>
                    {bus.active ? 'Active' : 'Inactive'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
};

export default ManageBuses;

