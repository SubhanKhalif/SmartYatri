import Layout from '../../components/Layout';
import '../../styles/global.css';

const VerifyPayment = () => {
  return (
    <Layout title="Verify Payment">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Payment Verification</h2>
        </div>
        <div className="text-center" style={{ padding: '2rem' }}>
          <p style={{ color: 'var(--text-secondary)' }}>
            Payment verification is handled in the Approve Passes section.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default VerifyPayment;

