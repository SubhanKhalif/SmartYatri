import Layout from '../../components/Layout';
import '../../styles/global.css';

const ManageUsers = () => {
  return (
    <Layout title="Manage Users">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">User Management</h2>
        </div>
        <div className="text-center" style={{ padding: '2rem' }}>
          <p style={{ color: 'var(--text-secondary)' }}>
            User management interface will be available here.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default ManageUsers;

