import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../styles/global.css';

const SignupPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    role: 'STUDENT',
    // Student fields
    class: '',
    division: '',
    rollNumber: '',
    // Staff fields
    department: '',
    employeeId: '',
    // Manager fields
    adminId: '',
    // Conductor fields
    conductorEmployeeId: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      const registrationData = {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        role: formData.role,
      };

      // Add role-specific fields
      if (formData.role === 'STUDENT') {
        registrationData.class = formData.class;
        registrationData.division = formData.division;
        registrationData.rollNumber = formData.rollNumber;
        registrationData.idNumber = formData.rollNumber;
      } else if (formData.role === 'STAFF') {
        registrationData.department = formData.department;
        registrationData.employeeId = formData.employeeId;
        registrationData.idNumber = formData.employeeId;
      } else if (formData.role === 'MANAGER') {
        registrationData.adminId = formData.adminId;
        registrationData.idNumber = formData.adminId;
      } else if (formData.role === 'CONDUCTOR') {
        registrationData.employeeId = formData.conductorEmployeeId;
        registrationData.idNumber = formData.conductorEmployeeId;
      }

      await register(registrationData);
      alert('Registration successful! Please login.');
      navigate('/login');
    } catch (err) {
      setError(err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const roles = [
    { value: 'STUDENT', label: 'Student' },
    { value: 'STAFF', label: 'Staff' },
    { value: 'MANAGER', label: 'Manager' },
    { value: 'CONDUCTOR', label: 'Conductor' },
  ];

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', padding: '2rem' }}>
      <div className="card" style={{ maxWidth: '500px', width: '100%' }}>
        <div className="text-center mb-6">
          <h1 style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>🚌 Register</h1>
          <p style={{ color: 'var(--text-secondary)' }}>Create your account to get started.</p>
        </div>

        {error && (
          <div className="alert alert-error mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input
              type="text"
              className="form-input"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              placeholder="Enter your full name"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              className="form-input"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
              placeholder="Enter your email"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Phone</label>
            <input
              type="tel"
              className="form-input"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="Enter your phone number"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Role</label>
            <select
              className="form-select"
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value })}
              required
            >
              {roles.map((role) => (
                <option key={role.value} value={role.value}>
                  {role.label}
                </option>
              ))}
            </select>
          </div>

          {/* Student-specific fields */}
          {formData.role === 'STUDENT' && (
            <>
              <div className="form-group">
                <label className="form-label">Class</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.class}
                  onChange={(e) => setFormData({ ...formData, class: e.target.value })}
                  placeholder="e.g., 10th"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Division</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.division}
                  onChange={(e) => setFormData({ ...formData, division: e.target.value })}
                  placeholder="e.g., A"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Roll Number</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.rollNumber}
                  onChange={(e) => setFormData({ ...formData, rollNumber: e.target.value })}
                  placeholder="Enter roll number"
                />
              </div>
            </>
          )}

          {/* Staff-specific fields */}
          {formData.role === 'STAFF' && (
            <>
              <div className="form-group">
                <label className="form-label">Department</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.department}
                  onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                  placeholder="Enter department"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Employee ID</label>
                <input
                  type="text"
                  className="form-input"
                  value={formData.employeeId}
                  onChange={(e) => setFormData({ ...formData, employeeId: e.target.value })}
                  placeholder="Enter employee ID"
                />
              </div>
            </>
          )}

          {/* Manager-specific fields */}
          {formData.role === 'MANAGER' && (
            <div className="form-group">
              <label className="form-label">Admin/Manager ID</label>
              <input
                type="text"
                className="form-input"
                value={formData.adminId}
                onChange={(e) => setFormData({ ...formData, adminId: e.target.value })}
                placeholder="Enter admin ID"
              />
            </div>
          )}

          {/* Conductor-specific fields */}
          {formData.role === 'CONDUCTOR' && (
            <div className="form-group">
              <label className="form-label">Employee ID</label>
              <input
                type="text"
                className="form-input"
                value={formData.conductorEmployeeId}
                onChange={(e) => setFormData({ ...formData, conductorEmployeeId: e.target.value })}
                placeholder="Enter employee ID"
              />
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-input"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              required
              placeholder="Enter password (min 6 characters)"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Confirm Password</label>
            <input
              type="password"
              className="form-input"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              required
              placeholder="Confirm password"
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            style={{ width: '100%', marginBottom: '1rem' }}
            disabled={loading}
          >
            {loading ? <span className="loading"></span> : 'Register'}
          </button>
        </form>

        <div className="text-center">
          <p style={{ color: 'var(--text-secondary)' }}>
            Already have an account?{' '}
            <Link to="/login" style={{ color: 'var(--primary)', textDecoration: 'none' }}>
              Login here
            </Link>
          </p>
          <Link to="/" style={{ color: 'var(--text-secondary)', textDecoration: 'none', fontSize: '0.875rem', marginTop: '1rem', display: 'inline-block' }}>
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default SignupPage;
