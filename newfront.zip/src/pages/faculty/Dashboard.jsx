import Layout from '../../components/Layout';
import '../../styles/global.css';

const FacultyDashboard = () => {
  return (
    <Layout title="Faculty Dashboard">
      <div className="card">
        <p style={{ color: 'var(--text-secondary)' }}>Faculty dashboard (use Staff/Student dashboard)</p>
      </div>
    </Layout>
  );
};

export default FacultyDashboard;

