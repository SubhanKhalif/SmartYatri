import { Navigate } from 'react-router-dom';

const FacultyMyPass = () => {
  return <Navigate to="/student/my-pass" replace />;
};

export default FacultyMyPass;

