import { Navigate } from 'react-router-dom';

const FacultyBookTicket = () => {
  return <Navigate to="/student/book-ticket" replace />;
};

export default FacultyBookTicket;

