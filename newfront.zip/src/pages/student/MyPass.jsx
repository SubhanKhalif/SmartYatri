import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { passAPI, authAPI } from '../../utils/api';
import '../../styles/global.css';

const MyPass = () => {
  const [currentPass, setCurrentPass] = useState(null);
  const [qrCode, setQrCode] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [passData, qrData] = await Promise.all([
        passAPI.getCurrentPass(),
        authAPI.getQRCode().catch(() => null),
      ]);
      setCurrentPass(passData.pass);
      setQrCode(qrData?.qrCode);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      ACTIVE: 'badge-success',
      PENDING: 'badge-warning',
      EXPIRED: 'badge-error',
      DISABLED: 'badge-error',
    };
    return badges[status] || 'badge-secondary';
  };

  if (loading) {
    return (
      <Layout title="My Pass">
        <div className="text-center">
          <div className="loading" style={{ width: '2rem', height: '2rem', margin: '2rem auto' }}></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="My Pass">
      <div className="grid grid-cols-2">
        {/* Pass Details */}
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Pass Details</h2>
          </div>
          {currentPass ? (
            <div>
              <div className="mb-4">
                <span className={`badge ${getStatusBadge(currentPass.status)} mb-2`}>
                  {currentPass.status}
                </span>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>
                  {currentPass.type} Pass
                </h3>
                <p style={{ color: 'var(--text-secondary)' }}>
                  Pass Code: <strong>{currentPass.passCode}</strong>
                </p>
              </div>
              {currentPass.route && (
                <div className="mb-4">
                  <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                    Route
                  </div>
                  <div style={{ fontWeight: '500' }}>
                    {currentPass.route.name}
                  </div>
                  <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                    {currentPass.route.startPoint} → {currentPass.route.endPoint}
                  </div>
                </div>
              )}
              <div className="grid grid-cols-2" style={{ gap: '1rem' }}>
                <div>
                  <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                    Start Date
                  </div>
                  <div style={{ fontWeight: '500' }}>
                    {new Date(currentPass.startDate).toLocaleDateString()}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                    End Date
                  </div>
                  <div style={{ fontWeight: '500' }}>
                    {new Date(currentPass.endDate).toLocaleDateString()}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center" style={{ padding: '2rem' }}>
              <p style={{ color: 'var(--text-secondary)' }}>
                No active pass found.
              </p>
            </div>
          )}
        </div>

        {/* QR Code */}
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">QR Code</h2>
          </div>
          <div className="text-center" style={{ padding: '2rem' }}>
            {qrCode ? (
              <div>
                <img
                  src={qrCode}
                  alt="QR Code"
                  style={{ maxWidth: '100%', marginBottom: '1rem' }}
                />
                <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  Show this QR code to the conductor for validation
                </p>
              </div>
            ) : (
              <div>
                <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📱</div>
                <p style={{ color: 'var(--text-secondary)' }}>
                  QR code will be available after pass approval
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default MyPass;

