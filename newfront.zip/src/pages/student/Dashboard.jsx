import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../../components/Layout';
import { passAPI, notificationAPI } from '../../utils/api';
import '../../styles/global.css';

const StudentDashboard = () => {
  const [currentPass, setCurrentPass] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [passData, notifData] = await Promise.all([
        passAPI.getCurrentPass(),
        notificationAPI.getNotifications(true),
      ]);
      setCurrentPass(passData.pass);
      setNotifications(notifData.notifications || []);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      ACTIVE: 'badge-success',
      PENDING: 'badge-warning',
      EXPIRED: 'badge-error',
      DISABLED: 'badge-error',
    };
    return badges[status] || 'badge-secondary';
  };

  const getDaysRemaining = (endDate) => {
    if (!endDate) return 0;
    const now = new Date();
    const end = new Date(endDate);
    const diff = Math.ceil((end - now) / (1000 * 60 * 60 * 24));
    return diff > 0 ? diff : 0;
  };

  if (loading) {
    return (
      <Layout title="Dashboard">
        <div className="text-center">
          <div className="loading" style={{ width: '2rem', height: '2rem', margin: '2rem auto' }}></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="Dashboard">
      {/* Current Pass Card */}
      <div className="card mb-6">
        <div className="card-header">
          <h2 className="card-title">Current Pass Status</h2>
        </div>
        {currentPass ? (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className={`badge ${getStatusBadge(currentPass.status)} mb-2`}>
                  {currentPass.status}
                </span>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>
                  {currentPass.type} Pass
                </h3>
                {currentPass.route && (
                  <p style={{ color: 'var(--text-secondary)' }}>
                    Route: {currentPass.route.name} ({currentPass.route.startPoint} → {currentPass.route.endPoint})
                  </p>
                )}
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: 'var(--primary)' }}>
                  {getDaysRemaining(currentPass.endDate)}
                </div>
                <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>days remaining</div>
              </div>
            </div>
            <div className="grid grid-cols-2" style={{ gap: '1rem' }}>
              <div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                  Start Date
                </div>
                <div style={{ fontWeight: '500' }}>
                  {new Date(currentPass.startDate).toLocaleDateString()}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                  End Date
                </div>
                <div style={{ fontWeight: '500' }}>
                  {new Date(currentPass.endDate).toLocaleDateString()}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center" style={{ padding: '2rem' }}>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '1rem' }}>
              You don't have an active pass yet.
            </p>
            <Link to="/student/book-ticket" className="btn btn-primary">
              Buy New Pass
            </Link>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-3 mb-6">
        <Link to="/student/book-ticket" className="card text-center" style={{ textDecoration: 'none' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🎫</div>
          <h3 style={{ fontSize: '1rem' }}>Buy Pass</h3>
        </Link>
        <Link to="/student/my-pass" className="card text-center" style={{ textDecoration: 'none' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🎟️</div>
          <h3 style={{ fontSize: '1rem' }}>My Pass</h3>
        </Link>
        <Link to="/student/travel-history" className="card text-center" style={{ textDecoration: 'none' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>📜</div>
          <h3 style={{ fontSize: '1rem' }}>History</h3>
        </Link>
      </div>

      {/* Notifications */}
      {notifications.length > 0 && (
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Notifications</h2>
          </div>
          <div>
            {notifications.slice(0, 5).map((notif) => (
              <div
                key={notif.id}
                style={{
                  padding: '1rem',
                  borderBottom: '1px solid var(--border-light)',
                  ...(notif.type === 'SUCCESS' && { background: '#d1fae5' }),
                  ...(notif.type === 'ERROR' && { background: '#fee2e2' }),
                  ...(notif.type === 'WARNING' && { background: '#fef3c7' }),
                }}
              >
                <div style={{ fontWeight: '500', marginBottom: '0.25rem' }}>{notif.title}</div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                  {notif.message}
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-light)', marginTop: '0.5rem' }}>
                  {new Date(notif.createdAt).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </Layout>
  );
};

export default StudentDashboard;

