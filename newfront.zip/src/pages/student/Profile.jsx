import Layout from '../../components/Layout';
import { useAuth } from '../../context/AuthContext';
import '../../styles/global.css';

const StudentProfile = () => {
  const { user } = useAuth();

  return (
    <Layout title="Profile">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Profile Information</h2>
        </div>
        {user && (
          <div>
            <div className="grid grid-cols-2" style={{ gap: '1.5rem' }}>
              <div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                  Name
                </div>
                <div style={{ fontWeight: '500', fontSize: '1.125rem' }}>
                  {user.name || 'N/A'}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                  Email
                </div>
                <div style={{ fontWeight: '500' }}>
                  {user.email}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                  Role
                </div>
                <div>
                  <span className="badge badge-info" style={{ textTransform: 'capitalize' }}>
                    {user.role?.toLowerCase()}
                  </span>
                </div>
              </div>
              {user.phone && (
                <div>
                  <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.25rem' }}>
                    Phone
                  </div>
                  <div style={{ fontWeight: '500' }}>
                    {user.phone}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default StudentProfile;

