import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { passAPI } from '../../utils/api';
import '../../styles/global.css';

const MyTickets = () => {
  const [passes, setPasses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPasses();
  }, []);

  const loadPasses = async () => {
    try {
      const data = await passAPI.getMyPasses();
      setPasses(data.passes || []);
    } catch (error) {
      console.error('Failed to load passes:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      ACTIVE: 'badge-success',
      PENDING: 'badge-warning',
      EXPIRED: 'badge-error',
      DISABLED: 'badge-error',
    };
    return badges[status] || 'badge-secondary';
  };

  if (loading) {
    return (
      <Layout title="My Tickets">
        <div className="text-center">
          <div className="loading" style={{ width: '2rem', height: '2rem', margin: '2rem auto' }}></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout title="My Tickets">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">All Passes</h2>
        </div>
        {passes.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>Pass Code</th>
                <th>Type</th>
                <th>Route</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Payment</th>
              </tr>
            </thead>
            <tbody>
              {passes.map((pass) => (
                <tr key={pass.id}>
                  <td>{pass.passCode}</td>
                  <td>{pass.type}</td>
                  <td>{pass.route?.name || 'N/A'}</td>
                  <td>{new Date(pass.startDate).toLocaleDateString()}</td>
                  <td>{new Date(pass.endDate).toLocaleDateString()}</td>
                  <td>
                    <span className={`badge ${getStatusBadge(pass.status)}`}>
                      {pass.status}
                    </span>
                  </td>
                  <td>
                    {pass.payments?.[0] ? (
                      <span className={`badge ${pass.payments[0].status === 'PAID' ? 'badge-success' : 'badge-warning'}`}>
                        {pass.payments[0].status}
                      </span>
                    ) : (
                      <span className="badge badge-secondary">N/A</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="text-center" style={{ padding: '2rem' }}>
            <p style={{ color: 'var(--text-secondary)' }}>No passes found.</p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default MyTickets;

