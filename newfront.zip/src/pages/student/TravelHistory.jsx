import Layout from '../../components/Layout';
import '../../styles/global.css';

const TravelHistory = () => {
  // This would fetch from an API endpoint for travel history
  // For now, showing a placeholder
  
  return (
    <Layout title="Travel History">
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Travel History</h2>
        </div>
        <div className="text-center" style={{ padding: '2rem' }}>
          <p style={{ color: 'var(--text-secondary)' }}>
            Travel history will be displayed here once you start using your pass.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default TravelHistory;

