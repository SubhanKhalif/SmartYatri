import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '../../components/Layout';
import { passAPI, routeAPI } from '../../utils/api';
import '../../styles/global.css';

const BookTicket = () => {
  const [routes, setRoutes] = useState([]);
  const [formData, setFormData] = useState({
    routeId: '',
    passType: 'MONTHLY',
    amount: '',
    paymentMethod: 'UPI',
    paymentReference: '',
    proofUrl: '',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    loadRoutes();
  }, []);

  const loadRoutes = async () => {
    try {
      const data = await routeAPI.getActiveRoutes();
      setRoutes(data.routes || []);
    } catch (error) {
      console.error('Failed to load routes:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await passAPI.purchasePass(formData);
      alert('Pass purchase request submitted! Waiting for manager approval.');
      navigate('/student/dashboard');
    } catch (err) {
      setError(err.message || 'Failed to purchase pass');
    } finally {
      setLoading(false);
    }
  };

  const passTypes = [
    { value: 'DAILY', label: 'Daily', price: 50 },
    { value: 'WEEKLY', label: 'Weekly', price: 300 },
    { value: 'MONTHLY', label: 'Monthly', price: 1000 },
  ];

  return (
    <Layout title="Buy Pass">
      <div className="container-sm">
        <div className="card">
          <div className="card-header">
            <h2 className="card-title">Purchase Bus Pass</h2>
          </div>

          {error && (
            <div className="alert alert-error mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Select Route</label>
              <select
                className="form-select"
                value={formData.routeId}
                onChange={(e) => setFormData({ ...formData, routeId: e.target.value })}
                required
              >
                <option value="">Choose a route...</option>
                {routes.map((route) => (
                  <option key={route.id} value={route.id}>
                    {route.name} ({route.startPoint} → {route.endPoint})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Pass Type</label>
              <select
                className="form-select"
                value={formData.passType}
                onChange={(e) => {
                  const selectedType = passTypes.find(t => t.value === e.target.value);
                  setFormData({
                    ...formData,
                    passType: e.target.value,
                    amount: selectedType ? selectedType.price : '',
                  });
                }}
                required
              >
                {passTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label} - ₹{type.price}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Amount (₹)</label>
              <input
                type="number"
                className="form-input"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
                min="1"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Payment Method</label>
              <select
                className="form-select"
                value={formData.paymentMethod}
                onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                required
              >
                <option value="UPI">UPI</option>
                <option value="QR">QR Code</option>
                <option value="BANK_TRANSFER">Bank Transfer</option>
                <option value="CASH">Cash</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Payment Reference/Transaction ID</label>
              <input
                type="text"
                className="form-input"
                value={formData.paymentReference}
                onChange={(e) => setFormData({ ...formData, paymentReference: e.target.value })}
                placeholder="Enter transaction ID or reference number"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Payment Proof URL (Optional)</label>
              <input
                type="url"
                className="form-input"
                value={formData.proofUrl}
                onChange={(e) => setFormData({ ...formData, proofUrl: e.target.value })}
                placeholder="https://example.com/payment-proof.jpg"
              />
              <small style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>
                Upload payment screenshot to a file hosting service and paste the URL here
              </small>
            </div>

            <div className="alert alert-info mb-4">
              <strong>Note:</strong> Your pass request will be reviewed by a manager. 
              You'll receive a notification once it's approved or rejected.
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              style={{ width: '100%' }}
              disabled={loading}
            >
              {loading ? <span className="loading"></span> : 'Submit Pass Request'}
            </button>
          </form>
        </div>
      </div>
    </Layout>
  );
};

export default BookTicket;

