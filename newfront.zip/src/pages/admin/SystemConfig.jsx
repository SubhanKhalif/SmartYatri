import Layout from '../../components/Layout';
import '../../styles/global.css';

const SystemConfig = () => {
  return (
    <Layout title="System Configuration">
      <div className="card">
        <p style={{ color: 'var(--text-secondary)' }}>System configuration will be available here.</p>
      </div>
    </Layout>
  );
};

export default SystemConfig;

