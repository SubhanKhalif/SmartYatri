import Layout from '../../components/Layout';
import '../../styles/global.css';

const AuditLogs = () => {
  return (
    <Layout title="Audit Logs">
      <div className="card">
        <p style={{ color: 'var(--text-secondary)' }}>Audit logs will be available here.</p>
      </div>
    </Layout>
  );
};

export default AuditLogs;

