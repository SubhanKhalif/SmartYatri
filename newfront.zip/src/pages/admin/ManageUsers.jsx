import Layout from '../../components/Layout';
import '../../styles/global.css';

const AdminManageUsers = () => {
  return (
    <Layout title="Manage Users">
      <div className="card">
        <p style={{ color: 'var(--text-secondary)' }}>User management (use Manager dashboard)</p>
      </div>
    </Layout>
  );
};

export default AdminManageUsers;

