import Layout from '../../components/Layout';
import '../../styles/global.css';

const AdminDashboard = () => {
  return (
    <Layout title="Admin Dashboard">
      <div className="card">
        <p style={{ color: 'var(--text-secondary)' }}>Admin dashboard (use Manager dashboard for admin functions)</p>
      </div>
    </Layout>
  );
};

export default AdminDashboard;

