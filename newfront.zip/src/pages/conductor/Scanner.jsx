import { useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import Layout from '../../components/Layout';
import { conductorAPI } from '../../utils/api';
import '../../styles/global.css';

const ConductorScanner = () => {
  const [scanResult, setScanResult] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState('');
  const [html5QrCode, setHtml5QrCode] = useState(null);

  const startScan = async () => {
    try {
      setError('');
      setScanResult(null);
      
      const qrCode = new Html5Qrcode('reader');
      setHtml5QrCode(qrCode);
      
      await qrCode.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
        },
        (decodedText) => {
          handleScan(decodedText);
        },
        (errorMessage) => {
          // Ignore scanning errors
        }
      );
      
      setScanning(true);
    } catch (err) {
      setError('Failed to start camera: ' + err.message);
      console.error('Scan error:', err);
    }
  };

  const stopScan = () => {
    if (html5QrCode) {
      html5QrCode.stop().then(() => {
        html5QrCode.clear();
        setHtml5QrCode(null);
        setScanning(false);
      }).catch((err) => {
        console.error('Stop scan error:', err);
      });
    }
  };

  const handleScan = async (qrId) => {
    try {
      stopScan();
      const data = await conductorAPI.scanQR(qrId);
      setScanResult(data);
    } catch (err) {
      setError('Scan failed: ' + err.message);
      setScanning(false);
    }
  };

  const handleManualInput = async (e) => {
    e.preventDefault();
    const qrId = e.target.qrId.value;
    if (qrId) {
      handleScan(qrId);
    }
  };

  const getResultColor = (result) => {
    const colors = {
      VALID: 'var(--success)',
      EXPIRED: 'var(--error)',
      PENDING: 'var(--warning)',
      INVALID: 'var(--error)',
    };
    return colors[result] || 'var(--text-secondary)';
  };

  return (
    <Layout title="QR Scanner">
      <div className="container-sm">
        {!scanning && !scanResult && (
          <div className="card mb-6">
            <div className="text-center">
              <div style={{ fontSize: '4rem', marginBottom: '1rem' }}>📱</div>
              <h2 style={{ marginBottom: '1rem' }}>Scan QR Code</h2>
              <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem' }}>
                Click the button below to start scanning, or enter QR code manually
              </p>
              <button onClick={startScan} className="btn btn-primary btn-lg" style={{ marginBottom: '2rem' }}>
                Start Camera Scanner
              </button>
              
              <form onSubmit={handleManualInput} style={{ marginTop: '2rem' }}>
                <div className="form-group">
                  <label className="form-label">Or Enter QR Code Manually</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      name="qrId"
                      className="form-input"
                      placeholder="Enter QR code ID"
                      required
                    />
                    <button type="submit" className="btn btn-secondary">
                      Verify
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {scanning && (
          <div className="card mb-6">
            <div id="reader" style={{ width: '100%' }}></div>
            <div className="text-center mt-4">
              <button onClick={stopScan} className="btn btn-danger">
                Stop Scanning
              </button>
            </div>
          </div>
        )}

        {error && (
          <div className="alert alert-error mb-6">
            {error}
          </div>
        )}

        {scanResult && (
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Scan Result</h2>
            </div>
            <div>
              <div className="text-center mb-4">
                <div
                  style={{
                    fontSize: '3rem',
                    padding: '1rem',
                    borderRadius: 'var(--radius-lg)',
                    background: getResultColor(scanResult.result),
                    color: 'white',
                    marginBottom: '1rem',
                  }}
                >
                  {scanResult.result === 'VALID' ? '✅' : scanResult.result === 'EXPIRED' ? '❌' : '⏳'}
                </div>
                <h3 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>
                  {scanResult.message}
                </h3>
                <span
                  className="badge"
                  style={{
                    background: getResultColor(scanResult.result),
                    color: 'white',
                    fontSize: '1rem',
                    padding: '0.5rem 1rem',
                  }}
                >
                  {scanResult.result}
                </span>
              </div>

              {scanResult.user && (
                <div className="mb-4" style={{ padding: '1rem', background: 'var(--bg-secondary)', borderRadius: 'var(--radius)' }}>
                  <h4 style={{ marginBottom: '0.5rem' }}>User Information</h4>
                  <div style={{ fontSize: '0.875rem' }}>
                    <div><strong>Name:</strong> {scanResult.user.name}</div>
                    <div><strong>Role:</strong> {scanResult.user.role}</div>
                  </div>
                </div>
              )}

              {scanResult.pass && (
                <div style={{ padding: '1rem', background: 'var(--bg-secondary)', borderRadius: 'var(--radius)' }}>
                  <h4 style={{ marginBottom: '0.5rem' }}>Pass Information</h4>
                  <div style={{ fontSize: '0.875rem' }}>
                    <div><strong>Type:</strong> {scanResult.pass.type}</div>
                    <div><strong>Status:</strong> {scanResult.pass.status}</div>
                    <div><strong>Valid From:</strong> {new Date(scanResult.pass.startDate).toLocaleDateString()}</div>
                    <div><strong>Valid Until:</strong> {new Date(scanResult.pass.endDate).toLocaleDateString()}</div>
                    {scanResult.pass.route && (
                      <div><strong>Route:</strong> {scanResult.pass.route.name}</div>
                    )}
                  </div>
                </div>
              )}

              <div className="text-center mt-6">
                <button
                  onClick={() => {
                    setScanResult(null);
                    setError('');
                  }}
                  className="btn btn-primary"
                >
                  Scan Another
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default ConductorScanner;

