import { Link } from 'react-router-dom';
import '../styles/global.css';

const HomePage = () => {
  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
      {/* Header */}
      <header style={{ padding: '1.5rem 0', background: 'rgba(255, 255, 255, 0.1)', backdropFilter: 'blur(10px)' }}>
        <div className="container">
          <div className="flex items-center justify-between">
            <div>
              <h1 style={{ color: 'white', fontSize: '1.5rem', fontWeight: 'bold' }}>
                🚌 School Bus Pass
              </h1>
              <p style={{ color: 'rgba(255, 255, 255, 0.9)', fontSize: '0.875rem' }}>
                Smart, Paperless Bus Pass System
              </p>
            </div>
            <div className="flex gap-4">
              <Link to="/login" className="btn btn-outline" style={{ background: 'white', color: '#667eea' }}>
                Login
              </Link>
              <Link to="/signup" className="btn btn-primary" style={{ background: 'white', color: '#667eea' }}>
                Register
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section style={{ padding: '4rem 0', textAlign: 'center', color: 'white' }}>
        <div className="container">
          <h1 style={{ fontSize: '3rem', marginBottom: '1rem', fontWeight: 'bold' }}>
            Smart Bus Pass System
          </h1>
          <p style={{ fontSize: '1.25rem', marginBottom: '2rem', opacity: 0.9, maxWidth: '600px', margin: '0 auto 2rem' }}>
            A modern, paperless solution for school bus ticket and pass booking. 
            Easy registration, QR-based validation, and seamless management.
          </p>
          <div className="flex gap-4 justify-center">
            <Link to="/signup" className="btn btn-lg" style={{ background: 'white', color: '#667eea', padding: '1rem 2rem' }}>
              Get Started
            </Link>
            <Link to="/login" className="btn btn-lg btn-outline" style={{ borderColor: 'white', color: 'white' }}>
              Login
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: '4rem 0', background: 'white' }}>
        <div className="container">
          <h2 style={{ textAlign: 'center', marginBottom: '3rem', fontSize: '2rem' }}>
            How It Works
          </h2>
          <div className="grid grid-cols-3" style={{ gap: '2rem' }}>
            <div className="card text-center">
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>👤</div>
              <h3 style={{ marginBottom: '0.5rem' }}>For Students & Staff</h3>
              <p style={{ color: 'var(--text-secondary)' }}>
                Register, purchase passes, get QR codes, and travel hassle-free. 
                View your pass status and history anytime.
              </p>
            </div>
            <div className="card text-center">
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>👨‍💼</div>
              <h3 style={{ marginBottom: '0.5rem' }}>For Managers</h3>
              <p style={{ color: 'var(--text-secondary)' }}>
                Manage buses, routes, and verify payments. Approve or reject pass requests 
                with a comprehensive dashboard.
              </p>
            </div>
            <div className="card text-center">
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🎫</div>
              <h3 style={{ marginBottom: '0.5rem' }}>For Conductors</h3>
              <p style={{ color: 'var(--text-secondary)' }}>
                Scan QR codes instantly to validate passes. Mobile-optimized interface 
                for quick verification on the go.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Role Selection */}
      <section style={{ padding: '4rem 0', background: 'var(--bg-secondary)' }}>
        <div className="container">
          <h2 style={{ textAlign: 'center', marginBottom: '3rem', fontSize: '2rem' }}>
            Login by Role
          </h2>
          <div className="grid grid-cols-4" style={{ gap: '1.5rem' }}>
            <Link to="/login?role=STUDENT" className="card text-center" style={{ textDecoration: 'none', transition: 'transform 0.2s' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>🎓</div>
              <h3>Student</h3>
            </Link>
            <Link to="/login?role=STAFF" className="card text-center" style={{ textDecoration: 'none', transition: 'transform 0.2s' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>👔</div>
              <h3>Staff</h3>
            </Link>
            <Link to="/login?role=MANAGER" className="card text-center" style={{ textDecoration: 'none', transition: 'transform 0.2s' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>👨‍💼</div>
              <h3>Manager</h3>
            </Link>
            <Link to="/login?role=CONDUCTOR" className="card text-center" style={{ textDecoration: 'none', transition: 'transform 0.2s' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>🎫</div>
              <h3>Conductor</h3>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: '2rem 0', background: 'var(--text-primary)', color: 'white', textAlign: 'center' }}>
        <div className="container">
          <p>&copy; 2024 School Bus Pass System. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;

