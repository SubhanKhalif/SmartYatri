import prisma from '../config/database.js';

// Get dashboard stats
export const getDashboardStats = async (req, res) => {
  try {
    const [
      totalStudents,
      totalStaff,
      activePasses,
      expiredPasses,
      pendingApprovals,
      scansToday,
    ] = await Promise.all([
      prisma.userLogin.count({ where: { loginType: 'STUDENT', status: 'active' } }),
      prisma.userLogin.count({ where: { loginType: 'STAFF', status: 'active' } }),
      prisma.pass.count({ where: { status: 'ACTIVE' } }),
      prisma.pass.count({ where: { status: 'EXPIRED' } }),
      prisma.pass.count({ where: { status: 'PENDING' } }),
      prisma.scan.count({
        where: {
          scannedAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0)),
          },
        },
      }),
    ]);

    res.json({
      stats: {
        totalStudents,
        totalStaff,
        activePasses,
        expiredPasses,
        pendingApprovals,
        scansToday,
      },
    });
  } catch (error) {
    console.error('Get dashboard stats error:', error);
    res.status(500).json({ error: 'Failed to get dashboard stats' });
  }
};

// Get all pending pass requests
export const getPendingPasses = async (req, res) => {
  try {
    const passes = await prisma.pass.findMany({
      where: { status: 'PENDING' },
      include: {
        user: {
          include: { profile: true },
        },
        route: true,
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ passes });
  } catch (error) {
    console.error('Get pending passes error:', error);
    res.status(500).json({ error: 'Failed to get pending passes' });
  }
};

// Approve pass
export const approvePass = async (req, res) => {
  try {
    const { passId } = req.params;

    const pass = await prisma.pass.findUnique({
      where: { id: parseInt(passId) },
      include: { payments: true },
    });

    if (!pass) {
      return res.status(404).json({ error: 'Pass not found' });
    }

    // Update pass status
    await prisma.pass.update({
      where: { id: parseInt(passId) },
      data: { status: 'ACTIVE' },
    });

    // Update payment status
    if (pass.payments.length > 0) {
      await prisma.payment.updateMany({
        where: { passId: parseInt(passId) },
        data: { status: 'PAID' },
      });
    }

    // Create notification
    await prisma.notification.create({
      data: {
        userId: pass.userId,
        title: 'Pass Approved',
        message: `Your ${pass.type} pass has been approved and is now active.`,
        type: 'SUCCESS',
      },
    });

    res.json({ message: 'Pass approved successfully' });
  } catch (error) {
    console.error('Approve pass error:', error);
    res.status(500).json({ error: 'Failed to approve pass' });
  }
};

// Reject pass
export const rejectPass = async (req, res) => {
  try {
    const { passId } = req.params;
    const { reason } = req.body;

    const pass = await prisma.pass.findUnique({
      where: { id: parseInt(passId) },
    });

    if (!pass) {
      return res.status(404).json({ error: 'Pass not found' });
    }

    // Update pass status
    await prisma.pass.update({
      where: { id: parseInt(passId) },
      data: { status: 'DISABLED' },
    });

    // Update payment status
    await prisma.payment.updateMany({
      where: { passId: parseInt(passId) },
      data: { status: 'FAILED' },
    });

    // Create notification
    await prisma.notification.create({
      data: {
        userId: pass.userId,
        title: 'Pass Rejected',
        message: `Your pass request has been rejected. ${reason || 'Please contact support for more information.'}`,
        type: 'ERROR',
      },
    });

    res.json({ message: 'Pass rejected successfully' });
  } catch (error) {
    console.error('Reject pass error:', error);
    res.status(500).json({ error: 'Failed to reject pass' });
  }
};

// Create bus
export const createBus = async (req, res) => {
  try {
    const { busNumber, numberPlate, capacity, driverName, conductorId, routeId } = req.body;

    if (!busNumber || !numberPlate || !capacity) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const bus = await prisma.bus.create({
      data: {
        busNumber,
        numberPlate,
        capacity: parseInt(capacity),
        driverName: driverName || null,
        conductorId: conductorId ? parseInt(conductorId) : null,
        routeId: routeId ? parseInt(routeId) : null,
      },
    });

    res.status(201).json({ message: 'Bus created successfully', bus });
  } catch (error) {
    console.error('Create bus error:', error);
    if (error.code === 'P2002') {
      return res.status(400).json({ error: 'Bus number or plate already exists' });
    }
    res.status(500).json({ error: 'Failed to create bus' });
  }
};

// Get all buses
export const getBuses = async (req, res) => {
  try {
    const buses = await prisma.bus.findMany({
      include: {
        conductor: {
          include: { profile: true },
        },
        route: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ buses });
  } catch (error) {
    console.error('Get buses error:', error);
    res.status(500).json({ error: 'Failed to get buses' });
  }
};

// Update bus
export const updateBus = async (req, res) => {
  try {
    const { busId } = req.params;
    const { busNumber, numberPlate, capacity, driverName, conductorId, routeId, active } = req.body;

    const bus = await prisma.bus.update({
      where: { id: parseInt(busId) },
      data: {
        ...(busNumber && { busNumber }),
        ...(numberPlate && { numberPlate }),
        ...(capacity && { capacity: parseInt(capacity) }),
        ...(driverName !== undefined && { driverName }),
        ...(conductorId !== undefined && { conductorId: conductorId ? parseInt(conductorId) : null }),
        ...(routeId !== undefined && { routeId: routeId ? parseInt(routeId) : null }),
        ...(active !== undefined && { active }),
      },
    });

    res.json({ message: 'Bus updated successfully', bus });
  } catch (error) {
    console.error('Update bus error:', error);
    res.status(500).json({ error: 'Failed to update bus' });
  }
};

// Create route
export const createRoute = async (req, res) => {
  try {
    const { name, startPoint, endPoint, stops, scheduleTime } = req.body;

    if (!name || !startPoint || !endPoint) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const route = await prisma.route.create({
      data: {
        name,
        startPoint,
        endPoint,
        stops: JSON.stringify(stops || []),
        scheduleTime: JSON.stringify(scheduleTime || []),
      },
    });

    res.status(201).json({ message: 'Route created successfully', route });
  } catch (error) {
    console.error('Create route error:', error);
    res.status(500).json({ error: 'Failed to create route' });
  }
};

// Get all routes
export const getRoutes = async (req, res) => {
  try {
    const routes = await prisma.route.findMany({
      include: {
        buses: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // Parse JSON fields
    const formattedRoutes = routes.map(route => ({
      ...route,
      stops: JSON.parse(route.stops || '[]'),
      scheduleTime: JSON.parse(route.scheduleTime || '[]'),
    }));

    res.json({ routes: formattedRoutes });
  } catch (error) {
    console.error('Get routes error:', error);
    res.status(500).json({ error: 'Failed to get routes' });
  }
};

// Update route
export const updateRoute = async (req, res) => {
  try {
    const { routeId } = req.params;
    const { name, startPoint, endPoint, stops, scheduleTime, active } = req.body;

    const route = await prisma.route.update({
      where: { id: parseInt(routeId) },
      data: {
        ...(name && { name }),
        ...(startPoint && { startPoint }),
        ...(endPoint && { endPoint }),
        ...(stops && { stops: JSON.stringify(stops) }),
        ...(scheduleTime && { scheduleTime: JSON.stringify(scheduleTime) }),
        ...(active !== undefined && { active }),
      },
    });

    res.json({ message: 'Route updated successfully', route });
  } catch (error) {
    console.error('Update route error:', error);
    res.status(500).json({ error: 'Failed to update route' });
  }
};

// Get scan activity
export const getScanActivity = async (req, res) => {
  try {
    const { limit = 50 } = req.query;

    const scans = await prisma.scan.findMany({
      take: parseInt(limit),
      include: {
        user: {
          include: { profile: true },
        },
        conductor: {
          include: { profile: true },
        },
        route: true,
        bus: true,
        pass: true,
      },
      orderBy: { scannedAt: 'desc' },
    });

    res.json({ scans });
  } catch (error) {
    console.error('Get scan activity error:', error);
    res.status(500).json({ error: 'Failed to get scan activity' });
  }
};

