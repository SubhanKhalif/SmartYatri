import prisma from '../config/database.js';

// Get all active routes
export const getActiveRoutes = async (req, res) => {
  try {
    const routes = await prisma.route.findMany({
      where: { active: true },
      include: {
        buses: {
          where: { active: true },
        },
      },
    });

    // Parse JSON fields
    const formattedRoutes = routes.map(route => ({
      ...route,
      stops: JSON.parse(route.stops || '[]'),
      scheduleTime: JSON.parse(route.scheduleTime || '[]'),
    }));

    res.json({ routes: formattedRoutes });
  } catch (error) {
    console.error('Get routes error:', error);
    res.status(500).json({ error: 'Failed to get routes' });
  }
};

