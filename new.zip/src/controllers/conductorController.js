import prisma from '../config/database.js';

// Scan QR code
export const scanQR = async (req, res) => {
  try {
    const { qrId } = req.body;

    if (!qrId) {
      return res.status(400).json({ error: 'QR code ID required' });
    }

    // Find user by QR ID
    const user = await prisma.userLogin.findFirst({
      where: {
        profile: {
          qrId,
        },
      },
      include: {
        profile: true,
      },
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Get current active pass
    const now = new Date();
    const pass = await prisma.pass.findFirst({
      where: {
        userId: user.id,
        status: 'ACTIVE',
        startDate: { lte: now },
        endDate: { gte: now },
      },
      include: {
        route: true,
      },
    });

    let scanResult = 'INVALID';
    let message = 'No active pass found';

    if (pass) {
      // Check if pass is expired
      if (new Date(pass.endDate) < now) {
        scanResult = 'EXPIRED';
        message = 'Pass has expired';
      } else {
        scanResult = 'VALID';
        message = 'Pass is valid';
      }
    } else {
      // Check if there's a pending pass
      const pendingPass = await prisma.pass.findFirst({
        where: {
          userId: user.id,
          status: 'PENDING',
        },
      });

      if (pendingPass) {
        scanResult = 'PENDING';
        message = 'Pass is pending manager approval';
      }
    }

    // Get conductor's assigned bus
    const conductorBus = await prisma.bus.findFirst({
      where: {
        conductorId: req.user.id,
        active: true,
      },
    });

    // Create scan record
    const scan = await prisma.scan.create({
      data: {
        userId: user.id,
        conductorId: req.user.id,
        passId: pass?.id || null,
        routeId: pass?.routeId || conductorBus?.routeId || null,
        busId: conductorBus?.id || null,
        scanResult,
      },
      include: {
        user: {
          include: { profile: true },
        },
        pass: {
          include: { route: true },
        },
        route: true,
        bus: true,
      },
    });

    // Create travel history if valid
    if (scanResult === 'VALID' && pass) {
      await prisma.travelHistory.create({
        data: {
          userId: user.id,
          routeId: pass.routeId,
          ticketType: 'PASS',
          passId: pass.id,
          conductorId: req.user.id,
          validatedAt: new Date(),
        },
      });
    }

    res.json({
      scan,
      result: scanResult,
      message,
      user: {
        id: user.id,
        name: user.profile?.fullName || user.email,
        role: user.loginType,
        photo: user.profile?.photo,
      },
      pass: pass ? {
        id: pass.id,
        type: pass.type,
        status: pass.status,
        startDate: pass.startDate,
        endDate: pass.endDate,
        route: pass.route,
      } : null,
    });
  } catch (error) {
    console.error('Scan QR error:', error);
    res.status(500).json({ error: 'Failed to scan QR code' });
  }
};

// Get conductor's scan history
export const getScanHistory = async (req, res) => {
  try {
    const { limit = 50 } = req.query;

    const scans = await prisma.scan.findMany({
      where: {
        conductorId: req.user.id,
      },
      take: parseInt(limit),
      include: {
        user: {
          include: { profile: true },
        },
        pass: true,
        route: true,
        bus: true,
      },
      orderBy: { scannedAt: 'desc' },
    });

    res.json({ scans });
  } catch (error) {
    console.error('Get scan history error:', error);
    res.status(500).json({ error: 'Failed to get scan history' });
  }
};

