import prisma from '../config/database.js';
import { v4 as uuidv4 } from 'uuid';

// Get all passes for current user
export const getMyPasses = async (req, res) => {
  try {
    const passes = await prisma.pass.findMany({
      where: { userId: req.user.id },
      include: {
        route: true,
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ passes });
  } catch (error) {
    console.error('Get passes error:', error);
    res.status(500).json({ error: 'Failed to get passes' });
  }
};

// Get current active pass
export const getCurrentPass = async (req, res) => {
  try {
    const now = new Date();
    const pass = await prisma.pass.findFirst({
      where: {
        userId: req.user.id,
        status: 'ACTIVE',
        startDate: { lte: now },
        endDate: { gte: now },
      },
      include: {
        route: true,
        payments: true,
      },
    });

    if (!pass) {
      return res.json({ pass: null });
    }

    res.json({ pass });
  } catch (error) {
    console.error('Get current pass error:', error);
    res.status(500).json({ error: 'Failed to get current pass' });
  }
};

// Purchase new pass
export const purchasePass = async (req, res) => {
  try {
    const { routeId, passType, amount, paymentMethod, paymentReference, proofUrl } = req.body;

    if (!routeId || !passType || !amount) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Validate route
    const route = await prisma.route.findUnique({
      where: { id: parseInt(routeId) },
    });

    if (!route) {
      return res.status(404).json({ error: 'Route not found' });
    }

    // Calculate dates based on pass type
    const startDate = new Date();
    const endDate = new Date();
    
    switch (passType.toUpperCase()) {
      case 'DAILY':
        endDate.setDate(endDate.getDate() + 1);
        break;
      case 'WEEKLY':
        endDate.setDate(endDate.getDate() + 7);
        break;
      case 'MONTHLY':
        endDate.setMonth(endDate.getMonth() + 1);
        break;
      default:
        return res.status(400).json({ error: 'Invalid pass type' });
    }

    // Generate unique pass code
    const passCode = `PASS-${uuidv4().substring(0, 8).toUpperCase()}`;

    // Create pass with payment
    const pass = await prisma.pass.create({
      data: {
        userId: req.user.id,
        routeId: parseInt(routeId),
        passCode,
        type: passType.toUpperCase(),
        status: 'PENDING',
        startDate,
        endDate,
        payments: {
          create: {
            userId: req.user.id,
            amount: parseInt(amount),
            status: 'PENDING',
            method: paymentMethod || 'UPI',
            reference: paymentReference || null,
            proofUrl: proofUrl || null,
          },
        },
      },
      include: {
        route: true,
        payments: true,
      },
    });

    // Create notification
    await prisma.notification.create({
      data: {
        userId: req.user.id,
        title: 'Pass Purchase Request',
        message: `Your ${passType} pass request has been submitted and is pending manager approval.`,
        type: 'INFO',
      },
    });

    res.status(201).json({
      message: 'Pass purchase request submitted',
      pass,
    });
  } catch (error) {
    console.error('Purchase pass error:', error);
    res.status(500).json({ error: 'Failed to purchase pass' });
  }
};

// Get pass history
export const getPassHistory = async (req, res) => {
  try {
    const passes = await prisma.pass.findMany({
      where: { userId: req.user.id },
      include: {
        route: true,
        payments: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    res.json({ passes });
  } catch (error) {
    console.error('Get pass history error:', error);
    res.status(500).json({ error: 'Failed to get pass history' });
  }
};

