import prisma from '../config/database.js';
import { hashPassword, verifyPassword, generateToken } from '../middleware/auth.js';
import { v4 as uuidv4 } from 'uuid';
import QRCode from 'qrcode';

// Register new user
export const register = async (req, res) => {
  try {
    const { email, password, name, phone, role, ...roleSpecificData } = req.body;

    // Validate role
    const validRoles = ['STUDENT', 'STAFF', 'MANAGER', 'CONDUCTOR'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    // Check if user already exists
    const existingUser = await prisma.userLogin.findUnique({
      where: { email },
    });

    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Generate unique QR ID
    const qrId = uuidv4();

    // Create user
    const user = await prisma.userLogin.create({
      data: {
        username: email,
        email,
        password: hashedPassword,
        phone: phone || null,
        loginType: role,
        status: 'active',
        profile: {
          create: {
            fullName: name,
            phone: phone || null,
            roleType: role === 'STUDENT' ? 'STUDENT' : 'STAFF',
            idNumber: roleSpecificData.idNumber || roleSpecificData.employeeId || roleSpecificData.adminId || null,
            classOrPosition: roleSpecificData.class || roleSpecificData.department || roleSpecificData.position || null,
            rollNumber: roleSpecificData.rollNumber || null,
            division: roleSpecificData.division || null,
            department: roleSpecificData.department || null,
            qrId,
          },
        },
      },
      include: {
        profile: true,
      },
    });

    res.status(201).json({
      message: 'Registration successful',
      user: {
        id: user.id,
        email: user.email,
        name: user.profile.fullName,
        role: user.loginType,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
};

// Login user
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    // Find user
    const user = await prisma.userLogin.findUnique({
      where: { email },
      include: {
        profile: true,
        assignedRole: true,
      },
    });

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check if user is active
    if (user.status !== 'active') {
      return res.status(403).json({ error: 'Account is inactive' });
    }

    // Verify password
    const isValid = await verifyPassword(password, user.password);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate token
    const token = generateToken();

    // Create session (expires in 7 days)
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    await prisma.session.create({
      data: {
        token,
        userId: user.id,
        expiresAt,
      },
    });

    // Update last login
    await prisma.userLogin.update({
      where: { id: user.id },
      data: { lastLogin: new Date() },
    });

    // Set token in httpOnly cookie
    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });

    res.json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        name: user.profile?.fullName || email,
        role: user.loginType,
        qrId: user.profile?.qrId,
      },
      token, // Also send in response for frontend storage if needed
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
};

// Logout user
export const logout = async (req, res) => {
  try {
    const token = req.cookies?.token || req.headers.authorization?.replace('Bearer ', '');

    if (token) {
      await prisma.session.deleteMany({
        where: { token },
      });
    }

    res.clearCookie('token');
    res.json({ message: 'Logout successful' });
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Logout failed' });
  }
};

// Get current user
export const getCurrentUser = async (req, res) => {
  try {
    const user = await prisma.userLogin.findUnique({
      where: { id: req.user.id },
      include: {
        profile: true,
        assignedRole: true,
      },
    });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.profile?.fullName || user.email,
        role: user.loginType,
        phone: user.phone || user.profile?.phone,
        qrId: user.profile?.qrId,
        profile: user.profile,
      },
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Failed to get user' });
  }
};

// Generate QR code image
export const getQRCode = async (req, res) => {
  try {
    const user = await prisma.userLogin.findUnique({
      where: { id: req.user.id },
      include: { profile: true },
    });

    if (!user?.profile?.qrId) {
      return res.status(404).json({ error: 'QR code not found' });
    }

    // Generate QR code as data URL
    const qrDataURL = await QRCode.toDataURL(user.profile.qrId, {
      width: 300,
      margin: 2,
    });

    res.json({
      qrId: user.profile.qrId,
      qrCode: qrDataURL,
      user: {
        name: user.profile.fullName,
        role: user.loginType,
      },
    });
  } catch (error) {
    console.error('QR code generation error:', error);
    res.status(500).json({ error: 'Failed to generate QR code' });
  }
};

