import prisma from '../config/database.js';

export const seedRoleData = async () => {
  try {
    // Create default roles if they don't exist
    const roles = ['STUDENT', 'STAFF', 'MANAGER', 'CONDUCTOR'];
    
    for (const roleName of roles) {
      await prisma.role.upsert({
        where: { name: roleName },
        update: {},
        create: {
          name: roleName,
          description: `${roleName} role`,
          isDefault: roleName === 'STUDENT',
        },
      });
    }

    console.log('✅ Role data seeded successfully');
  } catch (error) {
    console.error('❌ Error seeding role data:', error);
    throw error;
  }
};

