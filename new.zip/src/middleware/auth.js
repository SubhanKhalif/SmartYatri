import prisma from '../config/database.js';
import { v4 as uuidv4 } from 'uuid';
import bcrypt from 'bcryptjs';

// Generate a secure random token (256-bit equivalent)
export const generateToken = () => {
  return uuidv4() + uuidv4() + uuidv4() + uuidv4(); // 128 characters
};

// Hash password
export const hashPassword = async (password) => {
  return await bcrypt.hash(password, 10);
};

// Verify password
export const verifyPassword = async (password, hashedPassword) => {
  return await bcrypt.compare(password, hashedPassword);
};

// Middleware to verify token from database
export const isAuthenticated = async (req, res, next) => {
  try {
    const token = req.cookies?.token || req.headers.authorization?.replace('Bearer ', '');

    if (!token) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // Find session in database
    const session = await prisma.session.findUnique({
      where: { token },
      include: {
        user: {
          include: {
            profile: true,
            assignedRole: true,
          },
        },
      },
    });

    if (!session) {
      return res.status(401).json({ error: 'Invalid or expired token' });
    }

    // Check if token is expired (if expiresAt is set)
    if (session.expiresAt && new Date(session.expiresAt) < new Date()) {
      await prisma.session.delete({ where: { id: session.id } });
      return res.status(401).json({ error: 'Token expired' });
    }

    // Update lastUsed timestamp
    await prisma.session.update({
      where: { id: session.id },
      data: { lastUsed: new Date() },
    });

    // Attach user to request
    req.user = session.user;
    req.session = session;
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({ error: 'Authentication error' });
  }
};

// Role-based middleware
export const isStudent = (req, res, next) => {
  if (req.user?.loginType !== 'STUDENT') {
    return res.status(403).json({ error: 'Student access required' });
  }
  next();
};

export const isStaff = (req, res, next) => {
  if (req.user?.loginType !== 'STAFF') {
    return res.status(403).json({ error: 'Staff access required' });
  }
  next();
};

export const isManager = (req, res, next) => {
  if (req.user?.loginType !== 'MANAGER') {
    return res.status(403).json({ error: 'Manager access required' });
  }
  next();
};

export const isConductor = (req, res, next) => {
  if (req.user?.loginType !== 'CONDUCTOR') {
    return res.status(403).json({ error: 'Conductor access required' });
  }
  next();
};

export const isStudentOrStaff = (req, res, next) => {
  if (req.user?.loginType !== 'STUDENT' && req.user?.loginType !== 'STAFF') {
    return res.status(403).json({ error: 'Student or Staff access required' });
  }
  next();
};

