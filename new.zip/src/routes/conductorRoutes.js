import express from 'express';
import {
  scanQR,
  getScanHistory,
} from '../controllers/conductorController.js';
import { isAuthenticated, isConductor } from '../middleware/auth.js';

const router = express.Router();

router.use(isAuthenticated);
router.use(isConductor);

router.post('/scan', scanQR);
router.get('/scans', getScanHistory);

export default router;

