import express from 'express';
import authRoutes from './authRoutes.js';
import passRoutes from './passRoutes.js';
import managerRoutes from './managerRoutes.js';
import conductorRoutes from './conductorRoutes.js';
import routeRoutes from './routeRoutes.js';
import notificationRoutes from './notificationRoutes.js';

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/passes', passRoutes);
router.use('/manager', managerRoutes);
router.use('/conductor', conductorRoutes);
router.use('/routes', routeRoutes);
router.use('/notifications', notificationRoutes);

export default router;

