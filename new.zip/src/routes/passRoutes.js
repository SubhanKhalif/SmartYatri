import express from 'express';
import {
  getMyPasses,
  getCurrentPass,
  purchasePass,
  getPassHistory,
} from '../controllers/passController.js';
import { isAuthenticated, isStudentOrStaff } from '../middleware/auth.js';

const router = express.Router();

router.use(isAuthenticated);
router.use(isStudentOrStaff);

router.get('/my-passes', getMyPasses);
router.get('/current', getCurrentPass);
router.post('/purchase', purchasePass);
router.get('/history', getPassHistory);

export default router;

