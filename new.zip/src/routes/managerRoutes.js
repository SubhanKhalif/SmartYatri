import express from 'express';
import {
  getDashboardStats,
  getPendingPasses,
  approvePass,
  rejectPass,
  createBus,
  getBuses,
  updateBus,
  createRoute,
  getRoutes,
  updateRoute,
  getScanActivity,
} from '../controllers/managerController.js';
import { isAuthenticated, isManager } from '../middleware/auth.js';

const router = express.Router();

router.use(isAuthenticated);
router.use(isManager);

router.get('/dashboard/stats', getDashboardStats);
router.get('/passes/pending', getPendingPasses);
router.post('/passes/:passId/approve', approvePass);
router.post('/passes/:passId/reject', rejectPass);
router.post('/buses', createBus);
router.get('/buses', getBuses);
router.put('/buses/:busId', updateBus);
router.post('/routes', createRoute);
router.get('/routes', getRoutes);
router.put('/routes/:routeId', updateRoute);
router.get('/scans', getScanActivity);

export default router;

