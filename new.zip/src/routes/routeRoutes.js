import express from 'express';
import { getActiveRoutes } from '../controllers/routeController.js';

const router = express.Router();

router.get('/active', getActiveRoutes);

export default router;

