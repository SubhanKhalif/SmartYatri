import express from 'express';
import prisma from '../../lib/prisma.js';
import { validateSession } from '../../lib/auth.js';

const router = express.Router();

/**
 * Update user profile
 * PATCH /api/profile/update
 */
router.patch('/', async (req, res) => {
  try {
    const { user } = await validateSession(req);
    const { fullName, schoolName, idNumber, classOrPosition, photo } = req.body;

    // Get or create profile
    let profile = await prisma.userProfile.findUnique({
      where: { userId: user.id },
    });

    const updateData = {};
    if (fullName) updateData.fullName = fullName;
    if (schoolName !== undefined) updateData.schoolName = schoolName;
    if (idNumber !== undefined) updateData.idNumber = idNumber;
    if (classOrPosition !== undefined) updateData.classOrPosition = classOrPosition;
    if (photo !== undefined) updateData.photo = photo;

    if (profile) {
      profile = await prisma.userProfile.update({
        where: { userId: user.id },
        data: updateData,
      });
    } else {
      // Create profile if doesn't exist
      profile = await prisma.userProfile.create({
        data: {
          userId: user.id,
          fullName: fullName || user.username,
          schoolName: schoolName || null,
          roleType: user.loginType || 'STUDENT',
          idNumber: idNumber || null,
          classOrPosition: classOrPosition || null,
          photo: photo || null,
        },
      });
    }

    return res.json({
      success: true,
      profile: {
        id: profile.id,
        fullName: profile.fullName,
        schoolName: profile.schoolName,
        roleType: profile.roleType,
        idNumber: profile.idNumber,
        classOrPosition: profile.classOrPosition,
        photo: profile.photo,
        qrId: profile.qrId,
      },
    });
  } catch (err) {
    console.error('Error updating profile:', err);
    return res.status(err.status || 500).json({
      success: false,
      error: err.message || 'Failed to update profile',
    });
  }
});

/**
 * Get user profile
 * GET /api/profile
 */
router.get('/', async (req, res) => {
  try {
    const { user } = await validateSession(req);

    let profile = await prisma.userProfile.findUnique({
      where: { userId: user.id },
    });

    if (!profile) {
      return res.json({
        success: true,
        profile: null,
      });
    }

    return res.json({
      success: true,
      profile: {
        id: profile.id,
        fullName: profile.fullName,
        schoolName: profile.schoolName,
        roleType: profile.roleType,
        idNumber: profile.idNumber,
        classOrPosition: profile.classOrPosition,
        photo: profile.photo,
        qrId: profile.qrId,
        createdAt: profile.createdAt,
        updatedAt: profile.updatedAt,
      },
    });
  } catch (err) {
    console.error('Error getting profile:', err);
    return res.status(err.status || 500).json({
      success: false,
      error: err.message || 'Failed to get profile',
    });
  }
});

export default router;

